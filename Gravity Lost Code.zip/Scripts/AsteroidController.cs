﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidController : MonoBehaviour
{

    public int health;
    public float playerLocationZ;
    private PlayerController playerController;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerController = player.GetComponent<PlayerController>();
    }

    // Update is called once per frame
    void Update()
    {
        CheckForDestruction();
    }

    void CheckForDestruction()
    {
        playerLocationZ = player.transform.position.z;
        if (playerLocationZ > transform.position.z + 10)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter(Collider collidedObject)
    {
        if (collidedObject.tag == "Player")
        {
            playerController.ApplyHealthChange(-playerController.maxHealth);
            Destroy(gameObject);
        }

    }
    void ApplyHealthChange(int healthValue)
    {
        health += healthValue;
        if (health <= 0)
        {
            Destroy(gameObject);
        }
    }
}
