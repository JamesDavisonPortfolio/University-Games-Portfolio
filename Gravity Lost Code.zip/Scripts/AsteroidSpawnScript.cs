﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidSpawnScript : MonoBehaviour
{
    public GameObject[] asteroids;
    public GameObject player;
    public int spawnCode;
    public int maxAsteroids;
    public int asteroidCount;
    public bool spawning;
    public Quaternion asteroidRotation;
    public Vector3 spawnLocation;
    public float maxRangeX;
    public float maxRangeY;
    public float minRangeZ;
    public float maxRangez;

    // Start is called before the first frame update
    void Start()
    {
        spawning = true;
        StartCoroutine("SpawnEntity");
    }

    IEnumerator SpawnEntity()
    {
        while (spawning == true)
        {
            CountEnities();
            if (asteroidCount < maxAsteroids)
            {
                spawnLocation = new Vector3(player.transform.position.x + Random.Range(-maxRangeX, maxRangeX), player.transform.position.y + Random.Range(-maxRangeY, maxRangeY),
                    player.transform.position.z + Random.Range(minRangeZ, maxRangez));
                spawnCode = Random.Range(0, 2);
                asteroidRotation = Quaternion.Euler(Random.Range(0, 360), Random.Range(0, 360), Random.Range(0, 360));
                Instantiate(asteroids[spawnCode], spawnLocation, asteroidRotation);
            }
            yield return new WaitForEndOfFrame();
        }
    }
    void CountEnities()
    {
        asteroidCount = GameObject.FindGameObjectsWithTag("Asteroid").Length;
    }
}
