﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public int health;
    public int score;
    public float playerDistance;
    public float rotationSpeed;
    public float distanceToKeepAway;
    public Vector3 playerVector;
    public Vector3 gravitationalEffect;
    public Vector3 startPosition;
    public GameObject gravityWell;
    private PlayerController playerController;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerController = player.GetComponent<PlayerController>();
        startPosition = transform.position;
        distanceToKeepAway = Random.Range(70, 100);
    }

    // Update is called once per frame
    void Update()
    {
        //CalculateAndApplyGravitationalForce();
        transform.Rotate(0, 0, rotationSpeed * Time.deltaTime);
        EnemyMovement();
    }

    void EnemyMovement()
    {
        transform.position = startPosition + (transform.right * Mathf.Sin(Time.time)) * 15f;
        transform.position = new Vector3(transform.position.x, transform.position.y, player.transform.position.z + distanceToKeepAway);
        float playerPositionX = player.transform.position.x;
        float playerPositionY = player.transform.position.y;
        if(playerPositionX > gameObject.transform.position.x + 70 || playerPositionX < gameObject.transform.position.x - 70 ||
            playerPositionY > gameObject.transform.position.y + 70 || playerPositionY < gameObject.transform.position.y - 70)
        {
            transform.position = new Vector3(playerPositionX + Random.Range(-10, 10), playerPositionY + Random.Range(-10, 10), player.transform.position.z + distanceToKeepAway);
            startPosition = transform.position;
        }
    }

    void ApplyHealthChange(int healthValue)
    {
        health += healthValue;
        if (health <= 0)
        {
            playerController.UpdateEnemyScore(score);
            Instantiate(gravityWell, gameObject.transform.position, gravityWell.transform.rotation);
            Destroy(gameObject);
        }
    }
}
