﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCreationScript : MonoBehaviour
{
    public Mesh mesh;
    public Material material;
    public float childScale;
    public int depth;
    public int maxDepth;
    public Material[] materials;
    private static Vector3[] childDirection =
    {
        new Vector3(0, 1.1f, 0),
        new Vector3(1.1f, 0, 0),
        new Vector3(0, -1.1f, 0),
        new Vector3(-1.1f, 0, 0)
    };
    private static Quaternion[] childRotation =
    {
        Quaternion.Euler(0, 0, 30),
        Quaternion.Euler(0, 0, 300),
        Quaternion.Euler(0, 0, 210),
        Quaternion.Euler(0, 0, 120)
    };

    // Start is called before the first frame update
    void Start()
    {
        gameObject.AddComponent<MeshFilter>().mesh = mesh;
        if (depth == 0)
        {
            gameObject.AddComponent<MeshRenderer>().material = materials[0];
            gameObject.AddComponent<SphereCollider>();
            gameObject.GetComponent<SphereCollider>().isTrigger = true;
            maxDepth = Random.Range(2, 10);
            CreateFirstChildren();


        }
        else if (depth > 0 && depth < maxDepth)
        {
            gameObject.AddComponent<MeshRenderer>().material = materials[1];
            CreateFurtherChildren();
        }
        else
        {
            gameObject.AddComponent<MeshRenderer>().material = materials[2];
            gameObject.AddComponent<EnemyWeaponScript>();
        }
        if (depth > 0 && depth != maxDepth)
        {
            this.enabled = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (depth == 0)
        {
            gameObject.GetComponent<EnemyController>().health = maxDepth * 10;
            gameObject.GetComponent<EnemyController>().rotationSpeed = 200 / maxDepth;
            gameObject.GetComponent<EnemyController>().score = maxDepth * 100;
            this.enabled = false;
        }
    }

    void initialize(EnemyCreationScript parent, Vector3 direction, Quaternion rotation)
    {
        mesh = parent.mesh;
        materials = parent.materials;
        maxDepth = parent.maxDepth;
        depth = parent.depth + 1;
        childScale = parent.childScale;
        transform.parent = parent.transform;
        transform.localScale = Vector3.one * childScale;
        transform.localPosition = direction * (0.5f + 0.5f * childScale);
        transform.localRotation = rotation;
    }
    void CreateFirstChildren()
    {
        for (int i = 0; i < childDirection.Length; i++)
        {
            new GameObject("Enemy Child").AddComponent<EnemyCreationScript>().initialize(this, childDirection[i], childRotation[i]);
        }
    }
    void CreateFurtherChildren()
    {
        new GameObject("Enemy Child").AddComponent<EnemyCreationScript>().initialize(this, childDirection[0], childRotation[0]);
    }
}
