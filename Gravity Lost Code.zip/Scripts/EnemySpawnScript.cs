﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnScript : MonoBehaviour
{
    public GameObject enemy;
    public GameObject player;
    public int maxEnemies;
    public int enemyCount;
    public Vector3 spawnLocation;
    public float spawnWait;
    public float spawnDelay;
    public float maxRangeX;
    public float maxRangeY;
    public float minRangeZ;
    public float maxRangez;
    // Start is called before the first frame update
    void Start()
    {
        maxEnemies = 1;
        spawnWait = Random.Range(4f, 7f);
        spawnDelay = Time.time + spawnWait;
    }

    // Update is called once per frame
    void Update()
    {
        SpawnEntity();
        CountEnities();
    }
    void SpawnEntity()
    {
        if (enemyCount < maxEnemies && Time.time > spawnDelay)
        {
            spawnLocation = new Vector3(Random.Range(-maxRangeX, maxRangeX), Random.Range(-maxRangeY, maxRangeY),
                player.transform.position.z + Random.Range(minRangeZ, maxRangez));
            Instantiate(enemy, spawnLocation, enemy.transform.rotation);

            spawnWait = Random.Range(4f, 7f);
            spawnDelay = Time.time + spawnWait;
        }

    }
    void CountEnities()
    {
        enemyCount = GameObject.FindGameObjectsWithTag("Enemy").Length;
        maxEnemies = Mathf.RoundToInt(player.GetComponent<PlayerController>().distanceTravelled / 100);
    }
}
