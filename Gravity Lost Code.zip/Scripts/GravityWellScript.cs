﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityWellScript : MonoBehaviour
{
    public float gravityMultiplier;
    public float playerDistance;
    public float gravityForce;
    public float maxGravityDistance;
    public Vector3 playerVector;
    public Vector3 gravitationalEffect;
    private PlayerController playerController;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerController = player.GetComponent<PlayerController>();
        StartCoroutine("LifeOfWell");
    }

    // Update is called once per frame
    void Update()
    {
        CalculateAndApplyGravitationalForce();
    }

    void CalculateAndApplyGravitationalForce()
    {
        playerDistance = Vector3.Distance(player.transform.position, transform.position);
        if (playerDistance < maxGravityDistance)
        {
            playerVector = player.transform.position - transform.position;
            gravityForce = gravityMultiplier / playerDistance;
            gravitationalEffect = (playerVector / playerDistance) * -gravityForce;
            playerController.ApplyGravity(gravitationalEffect);
        }
    }
    private void OnTriggerEnter(Collider collidedObject)
    {
        if (collidedObject.tag == "Player")
        {
            playerController.ApplyHealthChange(-playerController.maxHealth);
            Destroy(gameObject);
        }
    }
    IEnumerator LifeOfWell()
    {
        yield return new WaitForSeconds(7);
        Destroy(gameObject);
    }
}
