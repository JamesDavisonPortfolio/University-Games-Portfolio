﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerController : MonoBehaviour
{
    public int playerHealth;
    public int maxHealth;
    public int playerLives;
    public int totalScore;
    public int distanceScore;
    public int enemyScore;
    public float distanceTravelled;
    public float rotationSpeed;
    public float baseVelocity;
    public float velocity;
    public float maxVelocity;
    public Vector3 rotation;
    public Vector3 startPosition;
    public float maxRotation;
    public GameObject healthBar;
    public GameObject[] lives;
    public AudioSource hitTakenSound;
    public AudioSource hitTakenSoundTwo;
    public GameObject hitTakenScreen;
    public TextMeshProUGUI scoreText;
    public GameObject eventSystem;


    // Start is called before the first frame update
    void Start()
    {
        playerHealth = 100;
        totalScore = 0;
        startPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        ThrusterControls();
        CalculateDistance();
        UpdateScore();
    }

    void ThrusterControls()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            velocity = baseVelocity * 2;
        }
        else if (Input.GetKey(KeyCode.LeftShift))
        {
            velocity = baseVelocity / 2;
        }
        else
        {
            velocity = baseVelocity;
        }
        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.up * Time.deltaTime * velocity;
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.position -= transform.up * Time.deltaTime * velocity;
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.position -= transform.right * Time.deltaTime * velocity;
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.position += transform.right * Time.deltaTime * velocity;
        }
        transform.position += Vector3.forward * Time.deltaTime * velocity;
        transform.Rotate(0, Input.GetAxis("Mouse X") * rotationSpeed * Time.deltaTime, 0);
        transform.Rotate(Input.GetAxis("Mouse Y") * -rotationSpeed * Time.deltaTime, 0, 0);
        RotationCap();
    }

    public void ApplyGravity(Vector3 force)
    {
        transform.position += force;
    }

    public void UpdateEnemyScore(int score)
    {
        enemyScore += score;
    }

    public void ApplyHealthChange(int healthValue)
    {
        playerHealth += healthValue;
        if(healthValue < 0)
        {
            StartCoroutine("HitTaken");
        }
        if (playerHealth < 0)
        {
            playerHealth = 0;
        }
        if (playerHealth > maxHealth)
        {
            playerHealth = maxHealth;
        }
        if (playerHealth == 0)
        {
            DeductLife();
        }
        SetHealthBar();
    }

    void CalculateDistance()
    {
        distanceTravelled = Mathf.Abs(startPosition.z - transform.position.z);
    }

    void UpdateScore()
    {
        int distance = Mathf.RoundToInt(distanceTravelled);
        distanceScore = distance * 10;
        totalScore = enemyScore + distanceScore;
        scoreText.SetText("Score: " + totalScore);
    }

    void DeductLife()
    {
        playerLives--;
        lives[playerLives].SetActive(false);
        if (playerLives > 0)
        {
            ApplyHealthChange(maxHealth);
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        if (playerLives == 0)
        {
            eventSystem.GetComponent<SceneController>().finalScore = totalScore;
            gameObject.transform.DetachChildren();
            Destroy(gameObject);
        }
    }

    void RotationCap()
    {
        if (transform.rotation.z > 0 || transform.rotation.z < 0)
        {
            transform.rotation = Quaternion.Euler(transform.eulerAngles.x, transform.eulerAngles.y, 0f);
        }
    }

    void SetHealthBar()
    {
        RectTransform chargeBarRectTransform = (RectTransform)healthBar.transform;
        chargeBarRectTransform.sizeDelta = new Vector2(playerHealth, chargeBarRectTransform.sizeDelta.y);
    }

    IEnumerator HitTaken()
    {
        hitTakenScreen.SetActive(true);
        hitTakenSound.Play();
        hitTakenSoundTwo.Play();
        yield return new WaitForSeconds(0.2f);
        hitTakenScreen.SetActive(false);
    }
}
