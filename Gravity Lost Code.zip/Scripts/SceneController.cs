﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SceneController : MonoBehaviour
{
    public AsteroidSpawnScript asteroidSpawner;
    public GameObject startUpScreens;
    public GameObject playCanvas;
    public GameObject gameOverScreen;
    public GameObject pauseScreen;
    public GameObject[] thingsToDeactivate;
    public AudioSource startUpMusic;
    public AudioSource gameMusic;
    public int finalScore;
    public TextMeshProUGUI finalScoreText;
    bool gamePaused;
    // Start is called before the first frame update
    private void Awake()
    {
        GameStartUp();
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.transform.parent == null)
        {
            GameOver();
        }
        if (Input.GetKeyDown(KeyCode.P) && gameObject.transform.parent != null)
        {
            PauseGame();
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }
    void GameStartUp()
    {
        Time.timeScale = 0;
        startUpScreens.SetActive(true);
        Cursor.lockState = CursorLockMode.Locked;
    }

    public void GamePlay()
    {
        startUpMusic.Stop();
        gameMusic.Play();
        Time.timeScale = 1;
        startUpScreens.SetActive(false);
        playCanvas.SetActive(true);
    }

    public void GameOver()
    {
        DeactivateExtras();
        playCanvas.SetActive(false);
        gameOverScreen.SetActive(true);
        finalScoreText.SetText("Final Score: " + finalScore);
        Time.timeScale = 0;
    }
    public void PauseGame()
    {
        if (gamePaused)
        {
            gameMusic.Play();
            pauseScreen.SetActive(false);
            Time.timeScale = 1;
            gamePaused = false;
        }
        else
        {
            gameMusic.Stop();
            pauseScreen.SetActive(true);
            Time.timeScale = 0;
            gamePaused = true;
        }
    }
    void DeactivateExtras()
    {
        thingsToDeactivate = GameObject.FindGameObjectsWithTag("EnemyLaser");
        for (int i = 0; i < thingsToDeactivate.Length; i++)
        {
            thingsToDeactivate[i].SetActive(false);
        }
        thingsToDeactivate = GameObject.FindGameObjectsWithTag("Enemy");
        for (int i = 0; i < thingsToDeactivate.Length; i++)
        {
            thingsToDeactivate[i].SetActive(false);
        }
        thingsToDeactivate = GameObject.FindGameObjectsWithTag("Asteroid");
        for (int i = 0; i < thingsToDeactivate.Length; i++)
        {
            thingsToDeactivate[i].SetActive(false);
        }
        gameObject.GetComponent<AsteroidSpawnScript>().enabled = false;
        gameObject.GetComponent<EnemySpawnScript>().enabled = false;
    }
}
