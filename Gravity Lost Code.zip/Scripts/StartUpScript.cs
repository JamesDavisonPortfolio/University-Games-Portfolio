﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartUpScript : MonoBehaviour
{
    public GameObject EventObject;
    public GameObject[] pages;
    public SceneController sceneController;
    public int pageNumber;
    // Start is called before the first frame update
    void Start()
    {
        sceneController = EventObject.GetComponent<SceneController>();
        pageNumber = 0;
        pages[0].SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if (pages[0].activeSelf == true)
        {
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            {
                sceneController.GamePlay();
            }
            else if (Input.GetKeyDown(KeyCode.Space))
            {
                pages[pageNumber].SetActive(false);
                pageNumber++;
            }
        }
        if (pages[0].activeSelf == false)
        {
            if (Input.GetKeyDown(KeyCode.RightArrow) && pageNumber != pages.Length - 1)
            {
                pages[pageNumber].SetActive(false);
                pageNumber++;
            }
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                pages[pageNumber].SetActive(false);
                pageNumber--;
            }
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            {
                sceneController.GamePlay();
            }
        }
        pages[pageNumber].SetActive(true);
    }
}
