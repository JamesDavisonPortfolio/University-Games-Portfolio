﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;

public class WeaponController : MonoBehaviour
{
    public GameObject laserClass;
    public GameObject chargeBar;
    public AudioSource laserNoise;
    public LineRenderer laser;
    public Image normalReticle;
    public Image inSightReticle;
    public float rateOfFire = 1f;
    public float charge;
    public float maxCharge;
    public float chargeAfterFireRate;
    public float continuousChargeRate;
    public float emptyChargeRate;
    public float chargeDelay;
    public float fireDelay;
    public bool isFiring;
    public int laserDamage;
    const float laserSpeed = 1600f;

    private void Start()
    {
        laser = gameObject.GetComponent<LineRenderer>();
        laser.enabled = false;
    }

    void Update()
    {
        Fire();
        SightCheck();
        RechargeWeapon();
        SetChargeBar();
    }
    void Fire()
    {
        if (Input.GetMouseButton(0) && Time.time > fireDelay && charge > 0)
        {
            isFiring = true;
            charge--;
            fireDelay = Time.time + rateOfFire;
            if (charge > 0)
            {
                chargeDelay = Time.time + chargeAfterFireRate;
            }
            else
            {
                chargeDelay = Time.time + emptyChargeRate;
            }
        }
        else
        {
            isFiring = false;
        }
    }

    void RechargeWeapon()
    {
        if (Time.time > chargeDelay && charge < maxCharge)
        {
            charge++;
            chargeDelay = Time.time + continuousChargeRate;
        }
    }
    void SightCheck()
    {
        RaycastHit hitObject;
        if (Physics.Raycast(transform.position, transform.forward, out hitObject, 200))
        {

            if (hitObject.collider.tag == "Enemy" || hitObject.collider.tag == "Asteroid")
            {
                normalReticle.enabled = false;
                inSightReticle.enabled = true;
                if (isFiring == true)
                {
                    hitObject.collider.SendMessageUpwards("ApplyHealthChange", laserDamage, SendMessageOptions.DontRequireReceiver);
                }
            }
        }
        else
        {
            normalReticle.enabled = true;
            inSightReticle.enabled = false;
        }
        if (isFiring == true)
        {
            StartCoroutine("LaserFire");
        }
    }
    void SetChargeBar()
    {
        RectTransform chargeBarRectTransform = (RectTransform)chargeBar.transform;
        chargeBarRectTransform.sizeDelta = new Vector2(charge, chargeBarRectTransform.sizeDelta.y);
    }
    IEnumerator LaserFire()
    {
        laserNoise.Play();
        laser.enabled = true;
        laser.SetPosition(0, gameObject.transform.position);
        laser.SetPosition(1, gameObject.transform.position + (transform.forward * 200));
        yield return new WaitForSeconds(0.1f);
        laser.enabled = false;
    }
}
