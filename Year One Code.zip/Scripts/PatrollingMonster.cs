﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
//James Alexander Davison
public class PatrollingMonster : MonoBehaviour
{
    #region Variable
    public float patrolWait;
    public float fightRange;
    public float attackRange;
    public ParticleSystem takeDamage;
    public ParticleSystem dealDamage;
    


    public Transform[] wayPoints;
    private int waypointIndex = 0;
    private float walkSpeed;
    private float attackSpeed;

    private GameObject player;
    private PlayerController playerController;
    private StatScript playerStats;
    private Transform playerTransform;
    private bool invincible;
    private float invincibleTime = 1;
    private float attackWait = 0;

    NavMeshAgent agent;
    StatScript charcterStats;
    #endregion
    void Awake()
    {

        player = GameObject.FindGameObjectWithTag("Player");
        playerController = player.GetComponent<PlayerController>();
        agent = GetComponent<NavMeshAgent>();
        playerStats = player.GetComponent<StatScript>();
        charcterStats = GetComponent<StatScript>();
        if(agent != null)
        {
            walkSpeed = agent.speed/2;
            attackSpeed = agent.speed;
            agent.speed = walkSpeed;
        }
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        InvokeRepeating("Tick", 0, 0.5f);
        InvokeRepeating("PatrolArea", 0, patrolWait);
    }
    void Update()
    {
        if (Vector3.Distance(transform.position, playerTransform.position) <= playerController.attackDistance)
        {
            if (playerController.hitting == true)
            {
                
                charcterStats.ApplyHealth(-(playerStats.currentDamage - charcterStats.currentDefence));
            }
        }
        agent.destination = wayPoints[waypointIndex].position;
        if (playerTransform != null && Vector3.Distance(transform.position, playerTransform.position) < fightRange)
        {
            agent.destination = playerTransform.position;
            agent.speed = attackSpeed;
            if (Vector3.Distance(transform.position, playerTransform.position) <= agent.stoppingDistance)
            {
                
                if (attackWait <= 0)
                {
                    
                    playerStats.ApplyHealth(-charcterStats.currentDamage + playerStats.currentDefence);
                    attackWait = 2;
                }
            }
        }
      
        attackWait -= Time.deltaTime;
    }
    void PatrolArea()
    {
        waypointIndex += 1;
        if (waypointIndex == wayPoints.Length)
        {
            waypointIndex = 0;
        }
    }
    void Tick()
    {
        
        
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, fightRange);
    }
}
