﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    //James Alexander Davison
    //variables created for use in player control
    private Rigidbody playerRigidB;
    public float attackDistance = 2;
    public float speed = 10;
    public float rotateSpeed = 50;

    public float currentTrack;
    public bool attacking;
    public bool hitting;

    private int hpPotions = 2;
    private int manaPotions = 2;

    private int potionRestore = 100;

    public TextMeshProUGUI HP;
    public TextMeshProUGUI MP;
    public TextMeshProUGUI hpPotTotal;
    public TextMeshProUGUI manaPotTotal;

    private float attackTime = 0;
    private StatScript playerStats;
    Transform sword;
    // Start is called before the first frame update
    void Start()
    {
        playerRigidB = GetComponent<Rigidbody>();
        sword = gameObject.transform.Find("Longsword");
        playerStats = GetComponent<StatScript>();
    }

    // Update is called once per frame
    void Update()
    {
        hitting = false;
        currentTrack = Time.time;
        PlayerMovement();
        if(attacking == false)
        {
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetMouseButtonDown(0))
            {
                sword.transform.Rotate(new Vector3(-15,60,0));
                Debug.Log("click working");
                attacking = true;
                hitting = true;
                
                attackTime = 0.5f;
            }
        }

        if (attacking == true && attackTime <= 0)
        {
            sword.transform.Rotate(new Vector3(15, -60, 0));
            Debug.Log("Is setting false");
            attacking = false;
        }
        if (Input.GetKeyDown(KeyCode.F) && hpPotions > 0)
        {
            playerStats.ApplyHealth(potionRestore);
            hpPotions -= 1;
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            playerStats.ApplyMana(potionRestore);
            manaPotions -= 1;
        }
        if(playerStats.currentMana > 10 && Input.GetKeyDown(KeyCode.Alpha1))
        {

        }
        attackTime -= Time.deltaTime;
        HP.text = "Health: " + playerStats.currentHealth + "/" + playerStats.maxHealth;
        MP.text = "Mana: " + playerStats.currentMana + "/" + playerStats.maxMana;
        hpPotTotal.text = "HP Potions: " + hpPotions;
        manaPotTotal.text = "Mana Potions: " + manaPotions;
    }
    void LateUpdate()
    {
        
    }
    void CastSpell()
    {

    }
    void PlayerMovement()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime * horizontalInput);
        transform.position += transform.forward * verticalInput * Time.deltaTime * speed;
        if (Input.GetKey(KeyCode.Q))
        {
            transform.position += transform.right * Time.deltaTime * -1 * speed;
        }
        if (Input.GetKey(KeyCode.E))
        {
            transform.position += transform.right * Time.deltaTime * 1 * speed;
        }
    }
}
