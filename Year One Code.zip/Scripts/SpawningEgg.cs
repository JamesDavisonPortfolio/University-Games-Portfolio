﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//James Alexander Davison;

public class SpawningEgg : MonoBehaviour
{
    private GameObject player;
    private PlayerController playerController;
    private StatScript playerStats;
    private Transform playerTransform;
    private float spawnLast = 0;
    private bool seenPlayer;
    public GameObject babyPrefab;
    public float spawnOffset;
    StatScript charcterStats;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerController = player.GetComponent<PlayerController>();
        playerStats = player.GetComponent<StatScript>();
        charcterStats = GetComponent<StatScript>();
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        InvokeRepeating("StartSpawning", 0, 5); // was supposed to be initialised with raycast to detect sight of player before spawning starting.
    }

    // Update is called once per frame
    void Update()
    {
        if (Vector3.Distance(transform.position, playerTransform.position) <= playerController.attackDistance)
        {
            if (playerController.hitting == true)
            {
                Debug.Log("attack run working");
                charcterStats.ApplyHealth(-(playerStats.currentDamage - charcterStats.currentDefence));
            }
        }
    }
    void StartSpawning()
    {
            Instantiate(babyPrefab, (transform.position + new Vector3(0, 0, spawnOffset)), Quaternion.identity);
    }
}
