﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
//James Alexander Davison
public class StatScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public TextMeshProUGUI gameOver;
    public Button restart;
    public GameObject healthPotion;
    public GameObject manaPotion;
    private int randomItem;

    //for level scheme to be implemented
    public int maxHealthLvl;
    public int maxManalvl;
    public int baseDamagelvl;
    public int baseDefencelvl;
    #region Character Stats

    public int maxHealth = 0;
    public int currentHealth = 0;

    public int maxMana = 0;
    public int currentMana = 0;

    public int maxWealth = 0;
    public int currentWealth = 0;

    public int baseDamage = 0;
    public int currentDamage = 0;

    public int baseDefence = 0;
    public int currentDefence = 0;

    public int charExperience = 0;
    public int charLevel = 0;
    #endregion

    #region Stat Changers
    public void ApplyHealth(int healthAmount)
    {
        Debug.Log("health amount supplied " + healthAmount);
        if (healthAmount > 0)
        {
            if (currentHealth + healthAmount > maxHealth)
            {
                currentHealth = maxHealth;
            }
            else
            {
                currentHealth += healthAmount;
            }
        }
        else if (healthAmount <= 0)
        {
            if (currentHealth + healthAmount <= 0)
            {
                Debug.Log("DeathTicked");
                if (!gameObject.CompareTag("Player") && !gameObject.CompareTag("Titan"))
                {
                    Debug.Log("Checked wasnt player");
                    Destroy(gameObject);
                    randomItem = Random.Range(1, 10);
                    if(randomItem == 1)
                    {
                        Instantiate(healthPotion);
                    }
                    else if( randomItem == 2)
                    {
                        Instantiate(manaPotion);
                    }
                }
                //set in a way to provide different text depending on if boss of player dies
                else if (gameObject.CompareTag("Player") || gameObject.CompareTag("Titan"))
                {
                    Destroy(gameObject);
                    currentHealth += healthAmount;
                    gameOver.gameObject.SetActive(true);
                    restart.gameObject.SetActive(true);

                }
            }
            else
            {
                currentHealth += healthAmount;
            }
        }
    }
    public void ApplyMana(int manaAmount)
    {
        if (manaAmount > 0)
        {
            if (currentMana + manaAmount > maxMana)
            {
                currentMana = maxMana;
            }
            else
            {
                currentMana += manaAmount;
            }
        }
        else if (manaAmount < 0)
        {
            if (currentMana + manaAmount <= 0)
            {
                currentMana = 0;
            }
            else
            {
                currentMana += manaAmount;
            }
        }
    }
    public void ApplyWealth(int wealthAmount)
    {
        if (wealthAmount > 0)
        {
            if (currentWealth + wealthAmount > maxWealth)
            {
                currentWealth = maxWealth;
            }
            else
            {
                currentWealth += wealthAmount;
            }
        }
        else if (wealthAmount < 0)
        {
            if (currentWealth + wealthAmount < 0)
            {
                currentWealth = maxWealth;
            }
            else
            {
                currentWealth += wealthAmount;
            }
        }
    }

    #endregion
}
